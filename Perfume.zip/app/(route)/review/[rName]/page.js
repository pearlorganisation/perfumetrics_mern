import WriteAReview from "@/app/_components/WriteAReview/WriteAReview";
import React from "react";

export default function page() {
  return (
    <div>
      <WriteAReview />
    </div>
  );
}

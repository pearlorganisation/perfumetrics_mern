"use client";

import Loader from "@/app/_components/Loader/Loader";

export default function Loading() {
  // Or a custom loading skeleton component
  return <Loader />;
}

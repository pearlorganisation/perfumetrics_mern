import Loader from "./_components/Loader/Loader";

export default function Loading() {
  // You can add any UI inside Loading, including a Skeleton.
  return <Loader />;
}
